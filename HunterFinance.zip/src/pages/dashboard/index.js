import React from 'react'
import Dashboard from '@/component/dashboard/dashboard'


const index = () => {
  return (
    <div>
        <Dashboard/>
       
    </div>
  )
}

export default index