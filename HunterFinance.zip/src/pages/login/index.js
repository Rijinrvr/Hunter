import React from 'react'
import Login from '../../component/login/login'

const index = () => {
  return (
    <div>
        <Login/>
    </div>
  )
}

export default index