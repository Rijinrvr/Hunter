// import * as React from "react";
// import { styled, useTheme } from "@mui/material/styles";
// import Box from "@mui/material/Box";
// import Drawer from "@mui/material/Drawer";
// import CssBaseline from "@mui/material/CssBaseline";
// import MuiAppBar from "@mui/material/AppBar";
// import Toolbar from "@mui/material/Toolbar";
// import List from "@mui/material/List";
// import ListItem from "@mui/material/ListItem";
// import ListItemIcon from "@mui/material/ListItemIcon";
// import ListItemText from "@mui/material/ListItemText";
// import DashboardIcon from "@mui/icons-material/Dashboard";
// import SettingsIcon from "@mui/icons-material/Settings";
// import PaymentsIcon from "@mui/icons-material/Payments";
// import PersonIcon from "@mui/icons-material/Person";
// import AppsIcon from "@mui/icons-material/Apps";
// import { Card, CardContent, CardHeader, Avatar, Grid } from "@mui/material";
// import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
// import AppBar from "@mui/material/AppBar";
// import image from "../../assest/Hunter-Financial-Logo.png";
// import "../../app/globals.css";

// const drawerWidth = 200;

// export default function PermanentDrawerLeft() {
//   const items = [
//     { text: "Dashboard", icon: <DashboardIcon /> },
//     { text: "Applications", icon: <AppsIcon /> },
//     { text: "Dealers", icon: <PersonIcon /> },
//     { text: "Rate Card", icon: <PaymentsIcon /> },
//     { text: "Settings", icon: <SettingsIcon /> },
//   ];

//   return (
//     <Box sx={{ display: "flex" }}>
//       <CssBaseline />
//       <AppBar
//         position="fixed"
//         sx={{ width: `calc(100% - ${drawerWidth}px)`, ml: `${drawerWidth}px` }}
//       ></AppBar>
//       <Drawer
//         sx={{
//           width: drawerWidth,
//           flexShrink: 0,
//           "& .MuiDrawer-paper": {
//             width: drawerWidth,
//             boxSizing: "border-box",
//           },
//         }}
//         variant="permanent"
//         anchor="left"
//       >
//         <img src={image.src} alt="Header" className="hunter-Finance-Logo" />
//         <Toolbar />
//         <Card className="side-Bar-Card">
//           <Grid>
//             <CardHeader
//               avatar={
//                 <Avatar>
//                   <AccountBalanceIcon />
//                 </Avatar>
//               }
//               title={
//                 <React.Fragment>
//                   Hunter Finance
//                   <br />
//                   Admin
//                 </React.Fragment>
//               }
//             />
//           </Grid>
//         </Card>

//         <List>
//           {items.map((item, index) => (
//             <ListItem button key={item.text}>
//               <ListItemIcon>{item.icon}</ListItemIcon>
//               <ListItemText primary={item.text} />
//             </ListItem>
//           ))}
//         </List>
//       </Drawer>
//     </Box>
//   );
// }

import React from "react";
import { Card, CardContent, CardHeader,Typography, Avatar, Grid } from "@mui/material";
import image from "../../assest/Hunter-Financial-Logo.png";
import cardImage from "../../assest/CardHead.png";

const sidebar = () => {
  return (
    <Grid container>
      <Grid item>
        <img src={image.src} className="hunter-Finance-Logo" />
      </Grid>
      <Grid>
        <Card className="side-Bar-Card">
          <img src={cardImage.src} className="card-Image" />
          <Typography className="card-Heading">Hunter Finance</Typography>
          <Typography className="card-Body">Admin</Typography>
          
        </Card>
      </Grid>
    </Grid>
  );
};

export default sidebar;
