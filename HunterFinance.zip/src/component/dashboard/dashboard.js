import React from "react";
import "../../app/globals.css";
import image from "../../assest/TestHeading.png";
import { Grid, Card, CardContent, Typography, Button } from "@mui/material";
import Sidebar from "../sidebar/sidebar";
import "../../app/globals.css";
import FolderCopyIcon from "@mui/icons-material/FolderCopy";
import AddTaskIcon from "@mui/icons-material/AddTask";
import DownloadingIcon from "@mui/icons-material/Downloading";
import PendingActionsIcon from "@mui/icons-material/PendingActions";
import TextField from "@mui/material/TextField";
import ListIcon from "@mui/icons-material/List";
import Table from "../dashboard/table";
import SearchIcon from "@mui/icons-material/Search";
import SearchBox from "../dashboard/searchBox";




const Dashboard = () => {
  const cardStyle = {
    backgroundColor: "white",
    color: "black",
    margin: "8px",
    marginLeft: "0",
    boxShadow: "6px 6px 5px 0px rgba(0,0,0,0.5)",
    display: "flex",
    flexDirection: "row",
    justifyContent: "flex-start",
    gap: "20px",
    width: "100%",
  };


  const cardData = [
    {
      title: "Total Application",
      value: 968,
      color: "#212B36",
      icon: <FolderCopyIcon />,
    },
    {
      title: "Completed Application",
      value: 800,
      color: "#219A22",
      icon: <AddTaskIcon />,
    },
    {
      title: "Turn Down Application",
      value: 108,
      color: "#2849D7",
      icon: <DownloadingIcon />,
    },
    {
      title: "Pending Application",
      value: 60,
      color: "#F5BA4F",
      icon: <PendingActionsIcon />,
    },
  ];

  const cardContainerStyle = {
    display: "flex",
    gap: "10px",
  };

  return (
    <Grid container spacing={5}>
      <Grid style={{ backgroundColor: "black" }}>
        <ListIcon />
      </Grid>

      <Grid item  lg={2.5}>
        <Sidebar />
      </Grid>

      <Grid item md={12} lg={9} xs={12}>
        <Grid>
          <Grid className="header-Style">
            <Button className="logout-Button">Logout</Button>
          </Grid>

          <Grid style={cardContainerStyle}>
            {cardData.map((card, index) => (
              <Card key={index}  className="card-Style">
                <CardContent>
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                    }}
                  >
                    <Grid
                      container
                      alignItems="center"
                      justify="center"
                      spacing={2}
                    >
                      <Grid item xs={12}>
                        <Typography className="dashboard-Card-Heading">
                          {card.title}
                        </Typography>
                      </Grid>
                      <Grid item xs={12}>
                        <Typography
                          style={{
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "space-between",
                          }}
                        >
                          <span 
                          style={{
                            color: card.color,
                            fontWeight: "800",
                            fontSize: "28px",
                            fontFamily: "Public Sans, sans-serif",
                            fontWeight: "bold"
                          }}
                          >
                            {card.value}
                          </span>
                          <span style={{ margin: "0 5px", color: card.color }}>
                            {card.icon}
                          </span>
                        </Typography>
                      </Grid>
                    </Grid>
                  </div>
                </CardContent>
              </Card>
            ))}
          </Grid>
        </Grid>
        <Grid item>
          <Typography
            variant="h4"
            gutterBottom
            style={{ color: "black", margin: "12px" }}
          >
            Applications
          </Typography>
        </Grid>
        <Grid item>
          <SearchBox />
        </Grid>
        <Grid>
          <Table />
          
        </Grid>
      </Grid>
    </Grid>
  );
};

export default Dashboard;
