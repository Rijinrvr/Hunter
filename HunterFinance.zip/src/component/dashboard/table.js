import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import ArrowUpwardIcon from '@mui/icons-material/ArrowUpward';

function createData(
  Customer,Submitted, Loan, Ez,Application, Contract, Amnt,Status){
  return { Customer,Submitted, Loan, Ez,Application, Contract, Amnt,Status};
  
}

const rows = [
  createData('Aasiya Jayavant', 'John Michael',1281,'003836',"2/15/2022","2/15/2022","$1,100.00", "pending"),
  createData('Aasiya Jayavant', 'John Michael',1281,'003836',"2/15/2022","2/15/2022","$1,100.00", "pending"),
  createData('Aasiya Jayavant', 'John Michael',1281,'003836',"2/15/2022","2/15/2022","$1,100.00", "pending"),
  createData('Aasiya Jayavant', 'John Michael',1281,'003836',"2/15/2022","2/15/2022","$1,100.00", "pending"),
  createData('Aasiya Jayavant', 'John Michael',1281,'003836',"2/15/2022","2/15/2022","$1,100.00", "pending"),
  createData('Aasiya Jayavant', 'John Michael',1281,'003836',"2/15/2022","2/15/2022","$1,100.00", "pending"),
  createData('Aasiya Jayavant', 'John Michael',1281,'003836',"2/15/2022","2/15/2022","$1,100.00", "pending"),
  
];

export default function BasicTable() {
  return (
    <TableContainer component={Paper} sx={{marginBottom: "30px",marginTop:"10px"}}>
      <Table sx={{ minWidth: 650}} aria-label="simple table">
        <TableHead style={{ background:"#ebe8e8"}}>
          <TableRow>
            <TableCell align="left">Customer</TableCell>
            <TableCell align="left">Submitted By </TableCell>
            <TableCell align="left">Loan </TableCell>
            <TableCell align="left">Ez Loan <br/> Number</TableCell>
            <TableCell align="left">Application <br/>Date</TableCell>
            <TableCell align="left">Contract  <br/> Date</TableCell>
            <TableCell align="left">Amnt <br/> Financed</TableCell>
            <TableCell align="left">Status </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.name}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell align="left">{row.Customer}</TableCell>
              <TableCell align="left">{row.Submitted}</TableCell>
              <TableCell align="left">{row.Loan}</TableCell>
              <TableCell align="left">{row.Ez}</TableCell>
              <TableCell align="left">{row.Application}</TableCell>
              <TableCell align="left">{row.Contract}</TableCell>
              <TableCell align="left">{row.Amnt}</TableCell>
              <TableCell align="left">{row.Status}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}