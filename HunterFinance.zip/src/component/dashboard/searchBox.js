import * as React from "react";
import Paper from "@mui/material/Paper";
import InputBase from "@mui/material/InputBase";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import SearchIcon from "@mui/icons-material/Search";
import DirectionsIcon from "@mui/icons-material/Directions";
import { Grid } from "@mui/material";
import ListIcon from "@mui/icons-material/List";

export default function CustomizedInputBase() {
  return (
    <Grid container lg={12}>
      <Grid item sm={10} md={10} lg={10}  >
        <Paper
          component="form"
          sx={{
            p: "2px 4px",
            display: "flex",
            alignItems: "center",
            width: 400,
          }}
        >
          <IconButton type="button" sx={{ p: "10px" }} aria-label="search">
            <SearchIcon />
          </IconButton>
          <InputBase
            sx={{ ml: 1, flex: 1 }}
            placeholder="Search"
            
          />
        </Paper>
      </Grid>
      <Grid item sm={2}  md ={2} lg={2}style={{ display: "flex", justifyContent: "flex-end" }}>
      <ListIcon className="menuIcon" />
      </Grid>
    </Grid>
  );
}
