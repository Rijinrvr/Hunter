import { createSlice } from "@reduxjs/toolkit";
import fetchTable from "./slice";

const initialState = {
  loading: false,
  table: [],
  error: "",
  filter: [],
  rowsPerPage: "",
  fromDate:"",
  toDate:"",
  searchKey:""
  
};

const tableData = createSlice({
  name: "tables",
  initialState,

  reducers: {

    setLocalStateToRedux: (state, action) => {
      state[action.payload.key] = action.payload.value;
      console.log(state.rowsPerPage, "rows"); 
    },
  },

  extraReducers: (builder) => {
    builder.addCase(fetchTable.pending, (state) => {
      state.loading = true;
      console.log("pending",  state.loading)
    });
    builder.addCase(fetchTable.fulfilled, (state, action) => {
      state.loading = false;
      state.table = action.payload;
      state.error = "";
      console.log("fulfilled",  state.loading)
    });

    builder.addCase(fetchTable.rejected, (state, action) => {
      state.loading = false;
      state.table = [];
      state.error = action.error.message;
      console.log("rejected",  state.loading)
    });
  },
});


export default tableData.reducer;

export function setReduxState(key, value, dispatch) {
  const data = {
    key,
    value,
  };
  return async () => {
    try {
      dispatch(tableData.actions.setLocalStateToRedux(data));
    } catch (error) {
      // Handle error
    }
  };
}
