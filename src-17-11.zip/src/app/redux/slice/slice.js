import { Filter1TwoTone } from "@mui/icons-material";
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

const bearerToken ="eyJhbGciOiJSUzI1NiIsImtpZCI6IjUzODVFQTI5RTk2MzhEMTA5MDRDODAyNkVBNzEwNTZBIiwidHlwIjoiYXQrand0In0.eyJuYmYiOjE3MDAyMTgwNTcsImV4cCI6MTcwMDIyMTY1NywiaXNzIjoiaHR0cHM6Ly9hdXRoZW50aWNhdGlvbi5odW50ZXJmaW5hbmNpYWwuY29tIiwiYXVkIjoiaHR0cHM6Ly9hdXRoZW50aWNhdGlvbi5odW50ZXJmaW5hbmNpYWwuY29tL3Jlc291cmNlcyIsImNsaWVudF9pZCI6Ikh1bnRlckRlYWxlclBvcnRhbCIsImp0aSI6Ijc5MTFFNkMyODM5MjZGRDlDN0YyMjgzMDNDMDA3NTdFIiwiaWF0IjoxNzAwMjE4MDU3LCJzY29wZSI6WyJIdW50ZXJGaW5hbmNlQXBpIl19.lz3qhIF4-rQFwGgZQMG_1eVhVK1QbpF5CBgjgdC5Y-3QdJ6BidpcOa6J7IY1akYwoiMIZIPj5VQGRozZcyL2ewlsfrieaHFNdZYAEk1PjW2x_FlZVTLkMM0vxozH1CN_XGVQ0M2wUgnM3zrcMKVcryf3ntsyO5PMbj4DvbPPMdTxH694Jv2pkGJ1q03tZZC_P2OIsOED12oSDsQwet5fy9W_HjfcQRyi-_lBE1-NHorrXjY1C6Jns0MU8YKHVgQFQ3-8AFSTGtAcEEMCS6lhHMsZKuXARi2KUzNZXRWOA9bJxCpxUI9YygOv1B-qKxonpoQNMSdC0B2aSaMemkp52g"
  const fetchTable = createAsyncThunk("/dashboard", async (payload) => {

const{status,pageSize,from,to,searchText} = payload

const statusString = status.join(',');


  try {
    const response = await axios.get(
      `https://apihunterfinance.oneteamus.com/api/dev/Application/List?PageNumber=&PageSize=${pageSize}&SortOrder=3&SortDir=1&UserID=233&searchText=${searchText}&fromDate=${from}&toDate=${to}&status=${statusString}`,
      {
        headers: {
          Authorization: `Bearer ${bearerToken}`,
        },
      }
    );
    const data = response.data.items;
    console.log("response",data)
    return data;
  } catch (error) {
    console.log(error.message);
  }
});

export default fetchTable;
