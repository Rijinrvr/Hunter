import {configureStore} from "@reduxjs/toolkit";
import tableReducer from "./slice/TableSlice"

 var store = configureStore({

    reducer:{
        tableReducer: tableReducer
    }
 })

 export default store;