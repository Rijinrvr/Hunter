import Sidebar from "../../component/sidebar/sidebar";
import React from "react";

const Settings = () => {
  return (
    <>
      <Sidebar />
      <div>Settings Page</div>
    </>
  );
};

export default Settings;
