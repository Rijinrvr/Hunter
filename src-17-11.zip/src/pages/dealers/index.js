import Sidebar from "../../component/sidebar/sidebar";
import React from "react";

const Dealers = () => {
  return (
    <>
      <Sidebar />
      <div>Dealers Page</div>
    </>
  );
};

export default Dealers;
