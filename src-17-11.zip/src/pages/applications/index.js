import { Grid } from "@mui/material";
import Sidebar from "../../component/sidebar/sidebar";
import React from "react";

const index = () => {
  return (
    <>
      <Grid container>
        <Grid item lg={2.5}>
          <Sidebar />
        </Grid>
        <Grid item lg={9.5}> 
          <div>Application page</div>
        </Grid>
      </Grid>
    </>
  );
};

export default index;
