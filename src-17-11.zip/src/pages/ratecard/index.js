import React from "react";
import Sidebar from "../../component/sidebar/sidebar";
const RateCard = () => {
  return (
    <>
      <Sidebar/>
      <div> Rate Card page</div>
    </>
  );
};

export default RateCard;
