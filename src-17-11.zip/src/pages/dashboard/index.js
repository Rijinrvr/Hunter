"use client";
import React from "react";
import Dashboard from "../../component/dashboard/dashboard";
import store from "../../app/redux/store";
import { Provider } from "react-redux";

const index = () => {
  return (
    <div>
      <Provider store={store}>
      <Dashboard />
      </Provider>
    </div>
  );
};

export default index;
