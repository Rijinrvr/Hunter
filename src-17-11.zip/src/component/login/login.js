"use client";
import React from "react";
import { Grid, TextField, Button } from "@mui/material";
import "../../app/globals.css";
import image from "../../assest/signup.jpg";
import Login from "../../assest/Login.png"
import { Dashboard } from "@mui/icons-material";
import { useRouter } from "next/navigation";

function login() {

  const router = useRouter();

  const test = () => {
    router.push("/dashboard")
  };


  return (
    <div className="main-container">
      <Grid container>
        <Grid item lg={6} display={{ xs: "none", lg: "block" }}>
          <div className="firstContainer">
            <img src={Login.src} alt="Login Image" className="loginImage" />
          </div>
        </Grid>
        <Grid item lg={6} xs={12} sm={12}>
          <div className="secondContainer">
            <div>
              <h3 className="test">Login</h3>
              <p className="test-login">
                Enter your email address and password
              </p>
              <Grid className="text-fields">
                <TextField label="Email Address" variant="outlined" />
              </Grid>
              <Grid className="text-fields">
                <TextField label="Password" variant="outlined" />
              </Grid>
              <Button
                className="login-Button"
                variant="contained"
                disableElevation
                onClick={test}
              >
                Login
              </Button>
            </div>
          </div>
        </Grid>
      </Grid>
    </div>
  );
}
export default login;
