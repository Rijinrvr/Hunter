import React, { useState } from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import CssBaseline from "@mui/material/CssBaseline";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import { Card, Typography, Grid } from "@mui/material";
import AppBar from "@mui/material/AppBar";
import image from "../../assest/Hunter-Financial-Logo.png";
import "../../app/globals.css";
import cardImage from "../../assest/CardHead.png";
import DashboardImage from "../../assest/Dashboard.svg";
import ApplicationsImage from "../../assest/Applications.svg";
import DealersImage from "../../assest/Dealers.svg";
import settingImage from "../../assest/Settings.svg";
import RateCardImage from "../../assest/RateCard.svg";
import { useRouter } from "next/router";

const drawerWidth = 200;

export default function Sidebar() {
  const router = useRouter();

  const items = [
    {
      text: "Dashboard",
      icon: <img src={DashboardImage.src} />,
      className: "dashboard",
    },
    {
      text: "Applications",
      icon: <img src={ApplicationsImage.src} />,
      className: "applications",
    },
    {
      text: "Dealers",
      icon: <img src={DealersImage.src} />,
      className: "dealers",
    },
    {
      text: "Rate Card",
      icon: <img src={RateCardImage.src} />,
      className: "ratecard",
    },
    {
      text: "Settings",
      icon: <img src={settingImage.src} />,
      className: "settings",
    },
  ];
  const handlePageRouter = (item) => {
    switch (item) {
      case "Dashboard":
        router.push("/dashboard");
        break;
      case "Applications":
        router.push("/applications");
        break;
      case "Dealers":
        router.push("/dealers");
        break;
      case "Rate Card":
        router.push("/ratecard");
        break;
      case "Settings":
        router.push("/settings");
        break;
      default:
        break;
    }
  };

  return (
    <Box sx={{ display: "flex" }}>
      <CssBaseline />
      <AppBar
        position="fixed"
        sx={{ width: `calc(100% - ${drawerWidth}px)`, ml: `${drawerWidth}px` }}
      ></AppBar>
      <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            boxSizing: "border-box",
          },
        }}
        variant="permanent"
        anchor="left"
      >
        <Grid item>
          <img src={image.src} className="hunter-Finance-Logo" />
        </Grid>
        <Toolbar />

        <Grid>
          <Card className="side-Bar-Card">
            <img src={cardImage.src} className="card-Image" />
            <Typography className="card-Heading">Hunter Finance</Typography>
            <Typography className="card-Body">Admin</Typography>
          </Card>
        </Grid>

        <List className="sidebar-Lists" as="ul">
          {items.map((item, index) => (
            <ListItem
              as="li"
              key={item.text}
              className={`${item.className} ${
                item.className === router.pathname.substring(1)
                  ? "active-Sidebar"
                  : ""
              }`}
              onClick={() => handlePageRouter(item.text)}
            >
              <ListItemIcon className="list-Logo">{item.icon}</ListItemIcon>
              <ListItemText primary={item.text} />
            </ListItem>
          ))}
        </List>
      </Drawer>
    </Box>
  );
}
