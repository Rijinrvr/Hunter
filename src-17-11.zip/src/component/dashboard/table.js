import * as React from "react";
import { Grid } from "@mui/material";
import { useState, useEffect } from "react";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableSortLabel from "@mui/material/TableSortLabel";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import "../../app/globals.css";
import TableSideArrowImage from "../../assest/Table-Side-Arrow.png";
import { useSelector, useDispatch } from "react-redux";
import fetchTable from "../../app/redux/slice/slice";
import Pagination from "../dashboard/paginationtest";
import Popup from "../dashboard/popup";
import Loader from "../dashboard/loader";
import moment from "moment";
function createData(
  Customer,
  Submitted,

  Ez,
  Application,
  Contract,
  Amnt,
  Status
) {
  return { Customer, Submitted, Ez, Application, Contract, Amnt, Status };
}

const rows = [
  createData(
    "Aasiya Jayavant",
    "John Michael",
    1281,
    "003836",
    "2/15/2022",
    "2/15/2022",
    "$1,100.00",
    "Pending"
  ),
  createData(
    "Aasiya Jayavant",
    "John Michael",
    1281,
    "003836",
    "2/15/2022",
    "2/15/2022",
    "$1,100.00",
    "Approved"
  ),
  createData(
    "Aasiya Jayavant",
    "John Michael",
    1281,
    "003836",
    "2/15/2022",
    "2/15/2022",
    "$1,100.00",
    "Turn Down"
  ),
  createData(
    "Aasiya Jayavant",
    "John Michael",
    1281,
    "003836",
    "2/15/2022",
    "2/15/2022",
    "$1,100.00",
    "Suspended"
  ),
  createData(
    "Aasiya Jayavant",
    "John Michael",
    1281,
    "003836",
    "2/15/2022",
    "2/15/2022",
    "$1,100.00",
    "Cancelled"
  ),
  createData(
    "Aasiya Jayavant",
    "John Michael",
    1281,
    "003836",
    "2/15/2022",
    "2/15/2022",
    "$1,100.00",
    "Active"
  ),
  createData(
    "Aasiya Jayavant",
    "John Michael",
    1281,
    "003836",
    "2/15/2022",
    "2/15/2022",
    "$1,100.00",
    "Pending"
  ),
];

const StatusCheck = (status) => {
  const result = status.toLowerCase();
  switch (result) {
    case "pending":
      return <span className="pending">{status}</span>;
    case "approved":
      return <span className="approved">{status}</span>;
    case "turndown":
      return <span className="turn-Down">{status}</span>;
    case "suspended":
      return <span className="suspend">{status}</span>;
    case "cancelled":
      return <span className="cancelled">{status}</span>;
    case "active":
      return <span className="active-Table">{status}</span>;
    default:
      return status;
  }
};

export default function BasicTable() {


  const tableData = useSelector((state) => state.tableReducer.table);
  console.log("data",tableData);

  const checkLoading = useSelector((state) => state.tableReducer.loading);

  const [sortConfig, setSortConfig] = useState({
    key: "",
    direction: "",
  });

  const requestSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  const sortedRows = [...rows].sort((a, b) => {
    if (sortConfig.direction === "asc") {
      return a[sortConfig.key].localeCompare(b[sortConfig.key]);
    } else if (sortConfig.direction === "desc") {
      return b[sortConfig.key].localeCompare(a[sortConfig.key]);
    }
    return 0;
  });

  return (
    <>
   
      <TableContainer
        className="main-Table"
        component={Paper}
        sx={{ marginBottom: "30px", marginTop: "10px" }}
      >
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead className="table-Head">
            <TableRow>
              <TableCell align="left">
                <TableSortLabel
                  active={sortConfig.key === "Customer"}
                  direction={
                    sortConfig.key === "Customer" ? sortConfig.direction : "asc"
                  }
                  onClick={() => requestSort("Customer")}
                >
                  Customer
                </TableSortLabel>
              </TableCell>

              <TableCell align="left">
                <TableSortLabel
                  active={sortConfig.key === "Submitted"}
                  direction={
                    sortConfig.key === "Submitted"
                      ? sortConfig.direction
                      : "asc"
                  }
                  onClick={() => requestSort("Submitted")}
                >
                  Submitted By
                </TableSortLabel>
              </TableCell>

              <TableCell align="left">
                <TableSortLabel
                  active={sortConfig.key === "Ez"}
                  direction={
                    sortConfig.key === "Ez" ? sortConfig.direction : "asc"
                  }
                  onClick={() => requestSort("Ez")}
                >
                  Ez Loan <br /> Number
                </TableSortLabel>
              </TableCell>

              <TableCell align="left">
                <TableSortLabel
                  active={sortConfig.key === "Application"}
                  direction={
                    sortConfig.key === "Application"
                      ? sortConfig.direction
                      : "asc"
                  }
                  onClick={() => requestSort("Application")}
                >
                  Application <br /> Date
                </TableSortLabel>
              </TableCell>

              <TableCell align="left">
                <TableSortLabel
                  active={sortConfig.key === "Contract"}
                  direction={
                    sortConfig.key === "Contract" ? sortConfig.direction : "asc"
                  }
                  onClick={() => requestSort("Contract")}
                >
                  Contract <br /> Date
                </TableSortLabel>
              </TableCell>

              <TableCell align="left">
                <TableSortLabel
                  active={sortConfig.key === "Amnt"}
                  direction={
                    sortConfig.key === "Amnt" ? sortConfig.direction : "asc"
                  }
                  onClick={() => requestSort("Amnt")}
                >
                  Amnt <br /> Financed
                </TableSortLabel>
              </TableCell>

              <TableCell align="left">
                <TableSortLabel
                  active={sortConfig.key === "Status"}
                  direction={
                    sortConfig.key === "Status" ? sortConfig.direction : "asc"
                  }
                  onClick={() => requestSort("Status")}
                >
                  Status
                </TableSortLabel>
              </TableCell>

              <TableCell align="left"></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {tableData?.map((row) => (
              <TableRow
                key={row.name}
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                className="table-Row"
              >
                <TableCell className="customer-Column" align="left">
                  {row.customerName}

    
                </TableCell>
                <TableCell className="table-Column" align="left">
                  {row.dealerName}
                </TableCell>

                <TableCell className="table-Column" align="left">
                  {row.ezloanLoanNumber}
            
                </TableCell>
                <TableCell className="table-Column" align="left">
                  {moment(row.createdDate).format("DD/MM/YYYY")}
               
                </TableCell>
                <TableCell className="table-Column" align="left">
                  {moment(row.contractDate).format("DD/MM/YYYY")}
                 
                </TableCell>
                <TableCell className="table-Column" align="left">
                  {row.amountFinanced}
               
                </TableCell>

                <TableCell className="table-Column" align="left">
                  {StatusCheck(row.status)}
                
                </TableCell>

                <TableCell className="table-Column" align="left">
                  <img className="side-Arrow" src={TableSideArrowImage.src} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <Grid item>
            <Pagination/>
      </Grid>
      </TableContainer>
 
    </>
  );
}
