import * as React from "react";
import TablePagination from "@mui/material/TablePagination";
import { setReduxState } from "../../app/redux/slice/TableSlice";
import { useSelector, useDispatch } from "react-redux";
import { useState, useEffect, useMemo } from "react";

function TablePaginationDemo() {
  const dispatch = useDispatch();
  const [page, setPage] = useState(2);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));

    setPage(0);
  };

  useEffect(() => {
 
    dispatch(setReduxState("rowsPerPage", rowsPerPage, dispatch));
  }, [rowsPerPage]);


  console.log("rowsPerPage", rowsPerPage);

  return (
    <TablePagination
      component="div"
      count={100}
      page={page}
      onPageChange={handleChangePage}
      rowsPerPage={rowsPerPage}
      onRowsPerPageChange={handleChangeRowsPerPage}
    />
  );
}

export default TablePaginationDemo;
