import React from "react";
import { useEffect, useState } from "react";
import "../../app/globals.css";
import { Grid, Card, CardContent, Typography, Button } from "@mui/material";
import Sidebar from "../sidebar/sidebar";
import "../../app/globals.css";
import Table from "../dashboard/table";
import SearchBox from "../dashboard/searchBox";
import TotalApplicationImage from "../../assest/TotalApplication.png";
import CompletedApplicationImage from "../../assest/Completed-Application.png";
import TurnDownApplicationImage from "../../assest/Turn-Down-Application.png";
import PendingApplicationImage from "../../assest/Pending-Application.png";
import { useSelector, useDispatch } from "react-redux";
import fetchTable from "../../app/redux/slice/slice";
import Loader from "../dashboard/loader";
import Pagination from "../dashboard/paginationtest"

const Dashboard = () => {
  const dispatch = useDispatch();

  //Getting filter Data
  const filterData = useSelector((state) => state.tableReducer.filter);
  const rowsPerPage = useSelector((state) => state.tableReducer.rowsPerPage);
  const loading = useSelector((state) => state.tableReducer.loading);
  console.log("loading",loading);
   const tableData = useSelector((state) => state.tableReducer.table);
  const fromDate = useSelector((state) => state.tableReducer.fromDate);
  const toDate = useSelector((state) => state.tableReducer.toDate);
  const searchText = useSelector((state) => state.tableReducer.searchKey);
console.log("fromDate",fromDate,toDate);

  useEffect(() => {
    const payload = {
      status: filterData,
      pageSize: rowsPerPage !== null ? rowsPerPage : 15,
      from: fromDate !== null ? fromDate : "",
      to: toDate !== null ? toDate : "",
      searchText: searchText ? searchText : "",
    };

    dispatch(fetchTable(payload));
  }, [filterData, rowsPerPage, fromDate, toDate, searchText]);

  const cardStyle = {
    backgroundColor: "white",
    color: "black",
    margin: "8px",
    marginLeft: "0",
    boxShadow: "6px 6px 5px 0px rgba(0,0,0,0.5)",
    display: "flex",
    flexDirection: "row",
    justifyContent: "flex-start",
    gap: "20px",
    width: "100%",
  };

  const cardData = [
    {
      title: "Total Application",
      value: 968,
      color: "#212B36",
      icon: <img src={TotalApplicationImage.src} />,
    },
    {
      title: "Completed Application",
      value: 800,
      color: "#219A22",
      icon: <img src={CompletedApplicationImage.src} />,
    },
    {
      title: "Turn Down Application",
      value: 108,
      color: "#2849D7",
      icon: <img src={TurnDownApplicationImage.src} />,
    },
    {
      title: "Pending Application",
      value: 60,
      color: "#F5BA4F",
      icon: <img src={PendingApplicationImage.src} />,
    },
  ];

  const cardContainerStyle = {
    display: "flex",
    gap: "10px",
  };

  return (
    <Grid container spacing={5}>
      <Grid item lg={3} display={{ xs: "none", lg: "block" }}>
        <Sidebar />
      </Grid>

      <Grid item xs={12} lg={9} sm={12} className="tester">
        <Grid>
          <Grid className="header-Style">
            <Button className="logout-Button">Logout</Button>
          </Grid>

          <Grid container spacing={3} className="test">
            {cardData.map((card, index) => (
              <Grid item lg={3} sm={3} xs={12}>
                <Card key={index} className="card-Style">
                  <CardContent>
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                      }}
                    >
                      <Grid
                        container
                        alignItems="center"
                        justify="center"
                        spacing={2}
                      >
                        <Grid item xs={12}>
                          <Typography className="dashboard-Card-Heading">
                            {card.title}
                          </Typography>
                        </Grid>
                        <Grid item xs={12}>
                          <Typography
                            style={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "space-between",
                            }}
                          >
                            <span
                              style={{
                                color: card.color,
                                fontWeight: "800",
                                fontSize: "32px",
                                fontFamily: "Public Sans, sans-serif",
                                fontWeight: "bold",
                              }}
                            >
                              {card.value}
                            </span>
                            <span
                              style={{ margin: "0 5px", color: card.color }}
                            >
                              {card.icon}
                            </span>
                          </Typography>
                        </Grid>
                      </Grid>
                    </div>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Grid>
        <Grid item className="application-Grid">
          <Typography className="dashboard-Heading">Applications</Typography>
        </Grid>
        <Grid item>
          <SearchBox />
        </Grid>
        <Grid item className="table-container">
          {loading ? (
            <Grid
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                height: "100vh",
              }}
            >
              <Loader />
            </Grid>
          ) : (
            <Table className="table" />
          )}
        </Grid>

      </Grid>
    </Grid>
  );
};

export default Dashboard;
