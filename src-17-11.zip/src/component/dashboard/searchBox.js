import React, { useEffect, useState } from "react";
import Paper from "@mui/material/Paper";
import InputBase from "@mui/material/InputBase";
import IconButton from "@mui/material/IconButton";
import SearchIcon from "@mui/icons-material/Search";
import { Grid, Typography } from "@mui/material";
import MenuImage from "../../assest/Component.png";
import Button from "@mui/material/Button";
import { usePopper } from "react-popper";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import Popup from "../dashboard/popup";
import {  useDispatch } from "react-redux";
import { setReduxState } from "../../app/redux/slice/TableSlice";

export default function CustomizedInputBase() {

  const dispatch = useDispatch();
const [searchValue,setSearchValue]= useState("")
console.log(searchValue,"search");

useEffect(() => {
  dispatch(setReduxState('searchKey', searchValue, dispatch));
}, [searchValue])



  return (
    <Grid container lg={12}>
      <Grid item sm={5.8} md={5.8} lg={5.8} xs={10}>
        <Paper component="form" className="search-Bar">
          <IconButton type="button" aria-label="search">
            <SearchIcon />
          </IconButton>
          <InputBase sx={{ ml: 1, flex: 1 }} placeholder="Search" onChange={(e)=>setSearchValue(e.target.value)} />
        </Paper>
      </Grid>
      <Grid
        item
        xs={2}
        sm={6.2}
        md={6.2}
        lg={6.2}
        style={{ display: "flex", justifyContent: "flex-end" }}
      >
        <Popup />
      </Grid>
    </Grid>
  );
}
