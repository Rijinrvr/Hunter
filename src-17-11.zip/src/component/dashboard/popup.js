import * as React from "react";
import { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import Popper from "@mui/material/Popper";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import Fade from "@mui/material/Fade";
import Paper from "@mui/material/Paper";
import MenuImage from "../../assest/Component.png";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { InputLabel } from "@mui/material";
import Checkbox from "@mui/material/Checkbox";
import { useSelector, useDispatch } from "react-redux";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import Border from "@mui/icons-material/PanoramaFishEye";
import fetchTable from "../../app/redux/slice/slice";
import { setReduxState } from "../../app/redux/slice/TableSlice";
import moment from "moment";
import dayjs from "dayjs";

export default function PositionedPopper() {
  const dispatch = useDispatch();

  const [anchorEl, setAnchorEl] = useState(null);
  const [open, setOpen] = useState(false);
  const [placement, setPlacement] = useState();
  const [selectedValue, setSelectedValue] = useState();
  const [filterValue, setFilterValue] = useState([]);
  const [fromDate, setFromDate] = useState();
  const [toDate, setToDate] = useState();

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };

  const handleClick = (newPlacement) => (event) => {
    setAnchorEl(event.currentTarget);
    setOpen((prev) => placement !== newPlacement || !prev);
    setPlacement(newPlacement);
 
  };

  const handleFromDate = (fromDateValue) => {
  
    const date = dayjs(fromDateValue);
    const formFormatDate = date.format("YYYY-MM-DD");
    setFromDate(formFormatDate);
    console.log("frompopup",fromDate);
  };

  const handleToDate = (toDateValue) => {
    const date = dayjs(toDateValue);
    const toformatDate = date.format("YYYY-MM-DD");
    setToDate(toformatDate);
    console.log("topopup",toDate);
  };

  const handleSubmit = () => {
    dispatch(setReduxState("filter", filterValue, dispatch));
    dispatch(setReduxState("fromDate", fromDate, dispatch));
    dispatch(setReduxState("toDate", toDate, dispatch));
    setOpen(false);
    handleClear();
  };

  const handleClear=()=>{
    setFilterValue('')
    setFromDate(null)
    setToDate(null)
  }
  const radioItems = [
    {
      text: "Show All",
      className: "show-All",
      status: "",
    },
    {
      text: "Pending",
      className: "pending-All",
      status: "PENDING",
    },
    {
      text: "Complete",
      className: "complete-All",
      status: "COMPLETE",
    },
    {
      text: "Approved",
      className: "approved-All",
      status: "APPROVED",
    },
    {
      text: "Active",
      className: "active-All",
      status: "ACTIVE",
    },
    {
      text: "Turn Down",
      className: "turn-Down-All",
      status: "TURNDOWN",
    },
  ];



 const handleFilter =(status)=>{
  if (!filterValue.includes(status)|| status === "") {
    setFilterValue(prevFilterValue => [...prevFilterValue, status]);
  }
 }


  return (
    <Box sx={{ width: 500 }}>
      <Popper open={open} anchorEl={anchorEl} placement={placement} transition>
        {({ TransitionProps }) => (
          <Fade {...TransitionProps} timeout={350}>
            <Paper className="testpopup">
              <Grid container className="top-popup">
                <Grid
                  item
                  className="popup-Heading"
                  justifyContent="space-between"
                >
                  Filter
                </Grid>
                <Grid item>
                  <a class="border-Button" onClick={handleClear}>Clear</a>
                </Grid>
              </Grid>

              <Grid container>
                <Grid item className="radio-Items">
                  <FormControl component="fieldset" className="radio-Buttons">
                    {radioItems.map((item, index) => (
                      <FormControlLabel
                        control={
                          <Checkbox
                            icon={<Border />}
                            checkedIcon={<CheckCircleIcon />}
                            name="checkedH"
                          />
                        }
                        label={item.text}
                        key={index}
                        className={item.className}
                        onChange={() => handleFilter(item.status)}
                      />
                    ))}
                  </FormControl>
                </Grid>
              </Grid>

              <Grid container>
                <Typography className="popup-Paragraph">
                  Filter by application date:
                </Typography>
              </Grid>

              <Grid container style={{ paddingTop: "15px" }}>
                <Grid item className="from-Datepicker">
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      label="From"
                      // value={dayjs(fromDate)}
                      value={fromDate}
                      onChange={(fromDateValue) => handleFromDate(fromDateValue)}
                    />
                  </LocalizationProvider>
                </Grid>
                <Grid item style={{ paddingLeft: "99px" }}>
                  <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <DatePicker
                      label="To"
                      // value={dayjs(toDate)}
                      value={toDate}
                      onChange={(toDateValue) => handleToDate(toDateValue)}
                    />
                  </LocalizationProvider>
                </Grid>
              </Grid>

              <Grid container style={{ paddingLeft: "15px" }}>
                <Grid>
                  <Button
                    className="tesing-Button"
                    variant="outlined"
                    onClick={handleSubmit}
                  >
                    Apply
                  </Button>
                </Grid>
              </Grid>
            </Paper>
          </Fade>
        )}
      </Popper>
      <Grid container justifyContent="center"></Grid>
      <Grid container justifyContent="right">
        <Grid item>
          <Button
            onClick={handleClick("left-start")}
            style={{
              borderRadius: "50%",
              width: "50px",
              height: "50px",
            }}
          >
            <img src={MenuImage.src} />
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
}
